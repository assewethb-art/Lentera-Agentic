"""Helper dasar: satu subagent = satu system prompt + satu panggilan Claude."""
from anthropic import Anthropic

from config import ANTHROPIC_API_KEY, MODEL_NAME

_client = Anthropic(api_key=ANTHROPIC_API_KEY)


def run_subagent(system_prompt: str, user_content: str, tools=None, max_tokens=1024) -> str:
    """Jalankan satu subagent: kirim system_prompt + user_content ke Claude,
    kembalikan teks jawabannya. `tools` opsional (misal web_search)."""
    kwargs = {
        "model": MODEL_NAME,
        "max_tokens": max_tokens,
        "system": system_prompt,
        "messages": [{"role": "user", "content": user_content}],
    }
    if tools:
        kwargs["tools"] = tools

    response = _client.messages.create(**kwargs)

    # Gabungkan semua blok teks dari respons (tool_use ditangani otomatis oleh
    # server-side tool seperti web_search, jadi biasanya sudah berupa teks).
    parts = [block.text for block in response.content if block.type == "text"]
    return "\n".join(parts).strip() or "(subagent tidak menghasilkan jawaban)"
