from subagents.base import run_subagent

SYSTEM_PROMPT = (
    "Kamu adalah subagent tanya-jawab umum. Jawab pertanyaan pengguna secara "
    "langsung, singkat, dan jelas dalam bahasa Indonesia kecuali diminta bahasa lain. "
    "Kamu tidak punya akses internet, jangan mengaku tahu info terkini."
)


def run(query: str) -> str:
    return run_subagent(SYSTEM_PROMPT, query)
