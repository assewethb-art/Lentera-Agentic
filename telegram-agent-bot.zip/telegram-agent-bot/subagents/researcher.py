from subagents.base import run_subagent

SYSTEM_PROMPT = (
    "Kamu adalah subagent riset. Gunakan web search untuk pertanyaan yang "
    "butuh informasi terkini (harga, berita, status terbaru, dsb). Jawab "
    "singkat dalam bahasa Indonesia, sebutkan sumbernya jika relevan."
)

WEB_SEARCH_TOOL = {"type": "web_search_20250305", "name": "web_search"}


def run(query: str) -> str:
    return run_subagent(SYSTEM_PROMPT, query, tools=[WEB_SEARCH_TOOL])
