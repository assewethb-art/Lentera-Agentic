"""Subagent reminder. Tidak memanggil Claude — cukup operasi database
langsung karena tugasnya terstruktur (set/list/batal), bukan open-ended."""
import time

import storage


def set_reminder(chat_id: int, text: str, minutes_from_now: float) -> str:
    due_at = time.time() + minutes_from_now * 60
    reminder_id = storage.add_reminder(chat_id, text, due_at)
    return f"Oke, reminder #{reminder_id} diset {minutes_from_now:g} menit dari sekarang: \"{text}\""


def list_reminders_text(chat_id: int) -> str:
    reminders = storage.list_reminders(chat_id)
    if not reminders:
        return "Tidak ada reminder aktif."
    lines = []
    for r in reminders:
        remaining_min = max(0, (r["due_at"] - time.time()) / 60)
        lines.append(f"#{r['id']}: \"{r['text']}\" (dalam ~{remaining_min:.0f} menit)")
    return "\n".join(lines)


def cancel(chat_id: int, reminder_id: int) -> str:
    ok = storage.cancel_reminder(chat_id, reminder_id)
    return f"Reminder #{reminder_id} dibatalkan." if ok else f"Reminder #{reminder_id} tidak ditemukan."
