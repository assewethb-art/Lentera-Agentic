"""Penyimpanan SQLite: riwayat percakapan per chat, dan daftar reminder."""
import sqlite3
import time
from contextlib import contextmanager

from config import DB_PATH


def init_db():
    with _conn() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                role TEXT NOT NULL,          -- 'user' atau 'assistant'
                content TEXT NOT NULL,
                created_at REAL NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS reminders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER NOT NULL,
                text TEXT NOT NULL,
                due_at REAL NOT NULL,
                sent INTEGER NOT NULL DEFAULT 0
            )
        """)
        c.commit()


@contextmanager
def _conn():
    conn = sqlite3.connect(DB_PATH)
    try:
        yield conn
    finally:
        conn.close()


def save_message(chat_id: int, role: str, content: str):
    with _conn() as c:
        c.execute(
            "INSERT INTO messages (chat_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (chat_id, role, content, time.time()),
        )
        c.commit()


def get_history(chat_id: int, limit: int):
    with _conn() as c:
        rows = c.execute(
            "SELECT role, content FROM messages WHERE chat_id = ? ORDER BY id DESC LIMIT ?",
            (chat_id, limit),
        ).fetchall()
    rows.reverse()
    return [{"role": role, "content": content} for role, content in rows]


def add_reminder(chat_id: int, text: str, due_at: float) -> int:
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO reminders (chat_id, text, due_at) VALUES (?, ?, ?)",
            (chat_id, text, due_at),
        )
        c.commit()
        return cur.lastrowid


def list_reminders(chat_id: int):
    with _conn() as c:
        rows = c.execute(
            "SELECT id, text, due_at FROM reminders WHERE chat_id = ? AND sent = 0 ORDER BY due_at",
            (chat_id,),
        ).fetchall()
    return [{"id": r[0], "text": r[1], "due_at": r[2]} for r in rows]


def cancel_reminder(chat_id: int, reminder_id: int) -> bool:
    with _conn() as c:
        cur = c.execute(
            "DELETE FROM reminders WHERE id = ? AND chat_id = ?",
            (reminder_id, chat_id),
        )
        c.commit()
        return cur.rowcount > 0


def due_reminders(now: float):
    """Reminder yang sudah lewat waktunya dan belum dikirim (untuk semua chat)."""
    with _conn() as c:
        rows = c.execute(
            "SELECT id, chat_id, text FROM reminders WHERE due_at <= ? AND sent = 0",
            (now,),
        ).fetchall()
    return [{"id": r[0], "chat_id": r[1], "text": r[2]} for r in rows]


def mark_reminder_sent(reminder_id: int):
    with _conn() as c:
        c.execute("UPDATE reminders SET sent = 1 WHERE id = ?", (reminder_id,))
        c.commit()
