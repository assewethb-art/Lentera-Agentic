# Telegram Agent Bot

Bot Telegram dengan pola **orchestrator + subagent**. Orchestrator (Claude)
menerima setiap pesan dan memutuskan sendiri subagent mana yang dipanggil:

- `qa` — tanya-jawab umum
- `researcher` — pertanyaan yang butuh info terkini (pakai web search)
- `reminder` — set / lihat / batalkan pengingat

Riwayat chat dan reminder disimpan di SQLite lokal (`bot.db`).

## 1. Amankan token bot

Kalau token bot Anda pernah tertulis di tempat yang tidak aman (chat, screenshot,
dll), **revoke dan buat baru** dulu lewat BotFather: `/mybots` → pilih bot →
**API Token** → **Revoke current token**.

## 2. Jalankan di lokal

```bash
cd telegram-agent-bot
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# lalu isi .env dengan TELEGRAM_BOT_TOKEN dan ANTHROPIC_API_KEY milik Anda

set -a && source .env && set +a   # muat .env ke environment (macOS/Linux)
python main.py
```

Buka chat dengan bot Anda di Telegram dan coba kirim pesan. Contoh:
- "halo" → dijawab subagent `qa`
- "harga bitcoin hari ini berapa?" → dijawab subagent `researcher`
- "ingetin aku minum air 30 menit lagi" → subagent `reminder`

## 3. Deploy ke Fly.io

Jalankan semua perintah ini **di komputer Anda sendiri** (bukan lewat saya —
lihat catatan di percakapan sebelumnya soal kenapa).

```bash
# Install flyctl kalau belum ada
curl -L https://fly.io/install.sh | sh

fly auth login          # atau: fly auth signup

cd telegram-agent-bot
fly launch --no-deploy   # jawab prompt nama app & region, TOLAK database apa pun

# Buat volume untuk SQLite (sesuaikan region dengan fly.toml)
fly volumes create bot_data --size 1 --region sin

# Set secrets — INI yang menggantikan .env, jangan taruh token di fly.toml
fly secrets set TELEGRAM_BOT_TOKEN=token-baru-anda
fly secrets set ANTHROPIC_API_KEY=sk-ant-...

fly deploy

# Pastikan minimal 1 machine selalu jalan (bot ini long-polling, bukan HTTP)
fly scale count 1

fly logs   # cek bot sudah "Bot mulai polling..."
```

## Menambah subagent baru

1. Buat file baru di `subagents/`, isinya fungsi `run(...)` seperti pola di
   `subagents/qa.py` atau `subagents/researcher.py`.
2. Daftarkan sebagai tool baru di `orchestrator.py`: tambah definisi di list
   `TOOLS`, dan tambah cabang di fungsi `_dispatch`.

Tidak perlu ubah `main.py` — orchestrator otomatis menawarkan tool baru itu
ke Claude di setiap pesan.

## Kenapa long polling, bukan webhook?

Lebih sederhana untuk mulai: tidak perlu domain, TLS, atau endpoint publik.
Konsekuensinya, machine harus tetap hidup 24/7 (`fly scale count 1`, tanpa
`http_service` yang auto-stop). Kalau nanti volumenya besar dan ingin
efisiensi biaya lebih baik, webhook + `http_service` adalah langkah lanjutan
yang wajar.
