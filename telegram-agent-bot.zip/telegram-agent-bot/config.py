"""Konfigurasi dari environment variable.

Semua nilai sensitif (token bot, API key) HARUS diisi lewat environment
variable / Fly secrets, jangan pernah ditulis langsung di kode.
"""
import os

TELEGRAM_BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]

# Model yang dipakai orchestrator dan semua subagent.
# Ganti lewat env var MODEL_NAME kalau perlu, tanpa ubah kode.
MODEL_NAME = os.environ.get("MODEL_NAME", "claude-sonnet-5")

# Lokasi file SQLite. Di Fly, arahkan ke path di dalam volume
# (misal /data/bot.db) supaya datanya tidak hilang saat redeploy.
DB_PATH = os.environ.get("DB_PATH", "bot.db")

# Berapa banyak pesan terakhir yang dikirim sebagai konteks ke orchestrator.
HISTORY_LIMIT = int(os.environ.get("HISTORY_LIMIT", "20"))
