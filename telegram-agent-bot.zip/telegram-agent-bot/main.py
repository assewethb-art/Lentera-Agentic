import asyncio
import logging

from telegram import Update
from telegram.ext import Application, MessageHandler, ContextTypes, filters

import storage
from config import TELEGRAM_BOT_TOKEN
from orchestrator import handle_message

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot")


async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    text = update.message.text or ""
    if not text.strip():
        return
    try:
        reply = handle_message(chat_id, text)
    except Exception:
        log.exception("Error saat memproses pesan dari chat %s", chat_id)
        reply = "Maaf, terjadi error di sisi server."
    await update.message.reply_text(reply)


async def check_reminders(app: Application):
    """Loop terpisah: setiap 15 detik cek reminder yang jatuh tempo dan kirim."""
    import time
    while True:
        for r in storage.due_reminders(time.time()):
            try:
                await app.bot.send_message(chat_id=r["chat_id"], text=f"⏰ Pengingat: {r['text']}")
            finally:
                storage.mark_reminder_sent(r["id"])
        await asyncio.sleep(15)


async def _post_init(app: Application):
    app.create_task(check_reminders(app))


def main():
    storage.init_db()
    app = Application.builder().token(TELEGRAM_BOT_TOKEN).post_init(_post_init).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message))
    log.info("Bot mulai polling...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
