"""Orchestrator: satu Claude call dengan daftar subagent sebagai 'tools'.
Claude sendiri yang memutuskan tool mana yang dipanggil, mungkin lebih dari
satu kali secara berurutan, sebelum memberi jawaban akhir ke pengguna."""
import json

from anthropic import Anthropic

import storage
from config import ANTHROPIC_API_KEY, MODEL_NAME, HISTORY_LIMIT
from subagents import qa, researcher, reminder

_client = Anthropic(api_key=ANTHROPIC_API_KEY)

SYSTEM_PROMPT = (
    "Kamu adalah orchestrator untuk bot Telegram. Kamu TIDAK menjawab sendiri "
    "kecuali sangat sederhana (sapaan, klarifikasi) — untuk pertanyaan nyata, "
    "panggil subagent yang sesuai lewat tool, lalu sampaikan hasilnya ke "
    "pengguna dalam bahasa Indonesia yang natural. Boleh memanggil beberapa "
    "tool berurutan kalau perlu."
)

TOOLS = [
    {
        "name": "ask_general",
        "description": "Tanya-jawab umum yang tidak butuh info terkini dari internet.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "ask_researcher",
        "description": "Pertanyaan yang butuh informasi terkini/aktual dari internet (harga, berita, status).",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
    {
        "name": "set_reminder",
        "description": "Set pengingat yang akan dikirim balik ke pengguna setelah sekian menit.",
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Isi pengingat"},
                "minutes_from_now": {"type": "number"},
            },
            "required": ["text", "minutes_from_now"],
        },
    },
    {
        "name": "list_reminders",
        "description": "Lihat semua reminder aktif milik pengguna ini.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "cancel_reminder",
        "description": "Batalkan satu reminder berdasarkan ID-nya.",
        "input_schema": {
            "type": "object",
            "properties": {"reminder_id": {"type": "integer"}},
            "required": ["reminder_id"],
        },
    },
]


def _dispatch(chat_id: int, tool_name: str, tool_input: dict) -> str:
    if tool_name == "ask_general":
        return qa.run(tool_input["query"])
    if tool_name == "ask_researcher":
        return researcher.run(tool_input["query"])
    if tool_name == "set_reminder":
        return reminder.set_reminder(chat_id, tool_input["text"], tool_input["minutes_from_now"])
    if tool_name == "list_reminders":
        return reminder.list_reminders_text(chat_id)
    if tool_name == "cancel_reminder":
        return reminder.cancel(chat_id, tool_input["reminder_id"])
    return f"(tool tidak dikenal: {tool_name})"


def handle_message(chat_id: int, user_text: str) -> str:
    storage.save_message(chat_id, "user", user_text)
    messages = storage.get_history(chat_id, HISTORY_LIMIT)

    # Loop tool-use standar: kirim, kalau model minta tool, jalankan, kirim
    # hasilnya balik, ulangi sampai model kasih jawaban teks final.
    for _ in range(5):  # batas aman supaya tidak looping tanpa henti
        response = _client.messages.create(
            model=MODEL_NAME,
            max_tokens=1024,
            system=SYSTEM_PROMPT,
            tools=TOOLS,
            messages=messages,
        )

        if response.stop_reason != "tool_use":
            final_text = "\n".join(b.text for b in response.content if b.type == "text").strip()
            storage.save_message(chat_id, "assistant", final_text)
            return final_text

        messages.append({"role": "assistant", "content": response.content})
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                result_text = _dispatch(chat_id, block.name, block.input)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": result_text,
                })
        messages.append({"role": "user", "content": tool_results})

    fallback = "Maaf, prosesnya terlalu panjang. Coba pertanyaan yang lebih spesifik."
    storage.save_message(chat_id, "assistant", fallback)
    return fallback
